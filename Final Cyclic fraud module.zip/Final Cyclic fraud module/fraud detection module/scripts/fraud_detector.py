import json
import os
import pandas as pd
from datetime import datetime, timedelta

# ----------------------------
# Helper: Date Parsing
# ----------------------------
def parse_date(date_str):
    """Convert 'DD/MM/YYYY' or similar to datetime; return None if invalid."""
    if pd.isna(date_str) or str(date_str).strip() == "":
        return None
    try:
        return datetime.strptime(str(date_str).strip(), "%d/%m/%Y")
    except ValueError:
        # Handle fallback formats
        try:
            return datetime.strptime(str(date_str).strip(), "%d/%m/%y")
        except ValueError:
            return None


# ----------------------------
# Core Fraud Detection Logic
# ----------------------------
def detect_fraud(customers_path, loans_path, transactions_path, groups_path, params_path, output_dir):
    # ---- Load Data ----
    customers = pd.read_csv(customers_path)
    loans = pd.read_csv(loans_path)
    transactions = pd.read_csv(transactions_path)

    with open(groups_path, "r") as f:
        groups = json.load(f)

    with open(params_path, "r") as f:
        params = json.load(f)

    # Parameters
    N = params.get("N", 3)      # Minimum funded customers threshold
    T = params.get("T", 10)     # Loan repayment window
    x = params.get("x", 5)      # Grace period
    a = params.get("a", 70)     # Min repayment ratio
    b = params.get("b", 100)    # Max repayment ratio

    # Convert date fields
    transactions["Trans_DT"] = transactions["Trans_DT"].apply(parse_date)
    loans["Start_Date"] = loans["Start_Date"].apply(parse_date)
    loans["Settlement_Date"] = loans["Settlement_Date"].apply(parse_date)

    # Transaction type sets
    credit_types = {"CREDIT_INT_TRANSFER", "CREDIT_EXT_TRANSFER", "CASH_CREDIT"}
    debit_types = {"DEBIT_INT_TRANSFER", "DEBIT_EXT_TRANSFER"}

    alerts = []
    alert_id_counter = 1

    # ===================================================
    # 1. EXISTING LOGIC: GROUP-BASED FRAUD DETECTION
    # ===================================================
    for group in groups:
        group_id = group["group_id"]
        members = set(group["group_members"])
        funded_customers = group["funded_customers"]

        # Skip if group funds fewer than N customers
        if len(funded_customers) < N:
            continue

        # Process each funded customer
        for cust_id in funded_customers:
            # Step 1: Credits from group to funded customer
            cust_txn = transactions[
                (transactions["Customer_ID"] == cust_id)
                & (transactions["Transaction_Type"].isin(credit_types))
                & (transactions["Derived_Counterparty_ID"].isin(members))
            ]

            if cust_txn.empty:
                continue

            credit_date = cust_txn["Trans_DT"].min()
            credit_amount = cust_txn["Amount"].sum()

            # Step 2: Loan settlement within T+x days
            settlement_window_end = credit_date + timedelta(days=T + x)
            cust_settlements = loans[
                (loans["Customer_ID"] == cust_id)
                & (loans["Transaction_Type"] == "LOAN SETTLEMENT")
                & (loans["Settlement_Date"].notna())
                & (loans["Settlement_Date"] >= credit_date)
                & (loans["Settlement_Date"] <= settlement_window_end)
            ]

            if cust_settlements.empty:
                continue

            settlement_date = cust_settlements["Settlement_Date"].min()
            settlement_amount = cust_settlements["Loan_Amount"].max()

            # Step 3: Repayment ratio
            ratio = (credit_amount / settlement_amount) * 100 if settlement_amount else 0
            if ratio < a or ratio > b:
                continue

            # Step 4: New loan after settlement
            new_loan_window_end = settlement_date + timedelta(days=T + x)
            cust_new_loans = loans[
                (loans["Customer_ID"] == cust_id)
                & (loans["Transaction_Type"] == "NEW LOAN")
                & (loans["Start_Date"].notna())
                & (loans["Start_Date"] >= settlement_date)
                & (loans["Start_Date"] <= new_loan_window_end)
            ]

            if cust_new_loans.empty:
                continue

            new_loan_date = cust_new_loans["Start_Date"].min()

            # Step 5: Return funds to group
            return_txn = transactions[
                (transactions["Customer_ID"] == cust_id)
                & (transactions["Transaction_Type"].isin(debit_types))
                & (transactions["Derived_Counterparty_ID"].isin(members))
                & (transactions["Trans_DT"] >= new_loan_date)
            ]

            if return_txn.empty:
                continue

            return_date = return_txn["Trans_DT"].min()

            # ---- Create Alert ----
            alert = {
                "alert_id": f"ALERT_{alert_id_counter:03}",
                "group_id": group_id,
                "funded_customer": cust_id,
                "repayment_ratio": ratio,
                "fund_flow": {
                    "initial_credit_date": credit_date.strftime("%d/%m/%Y") if credit_date else None,
                    "settlement_date": settlement_date.strftime("%d/%m/%Y") if settlement_date else None,
                    "new_loan_date": new_loan_date.strftime("%d/%m/%Y") if new_loan_date else None,
                    "return_txn_date": return_date.strftime("%d/%m/%Y") if return_date else None,
                },
                "status": "SUSPECTED_CIRCULAR_FUND_FLOW"
            }
            alerts.append(alert)
            alert_id_counter += 1

    # ===================================================
    # 2. NEW LOGIC: INDIVIDUAL SENDER FUNDING FRAUD DETECTION
    # ===================================================
    # Step A: Identify individual senders funding N or more distinct customers
    credit_txns = transactions[transactions["Transaction_Type"].isin(credit_types)]

    sender_to_recipients = (
        credit_txns.groupby("Derived_Counterparty_ID")["Customer_ID"]
        .nunique()
        .reset_index()
        .rename(columns={"Customer_ID": "recipient_count"})
    )

    eligible_senders = sender_to_recipients[
        sender_to_recipients["recipient_count"] >= N
    ]["Derived_Counterparty_ID"].tolist()

    # Step B: For each eligible sender, check funded customers individually
    for sender_id in eligible_senders:
        funded_customers = credit_txns[
            credit_txns["Derived_Counterparty_ID"] == sender_id
        ]["Customer_ID"].unique()

        for cust_id in funded_customers:
            # Same fraud cycle check as group logic
            cust_txn = transactions[
                (transactions["Customer_ID"] == cust_id)
                & (transactions["Transaction_Type"].isin(credit_types))
                & (transactions["Derived_Counterparty_ID"] == sender_id)
            ]

            if cust_txn.empty:
                continue

            credit_date = cust_txn["Trans_DT"].min()
            credit_amount = cust_txn["Amount"].sum()

            settlement_window_end = credit_date + timedelta(days=T + x)
            cust_settlements = loans[
                (loans["Customer_ID"] == cust_id)
                & (loans["Transaction_Type"] == "LOAN SETTLEMENT")
                & (loans["Settlement_Date"].notna())
                & (loans["Settlement_Date"] >= credit_date)
                & (loans["Settlement_Date"] <= settlement_window_end)
            ]

            if cust_settlements.empty:
                continue

            settlement_date = cust_settlements["Settlement_Date"].min()
            settlement_amount = cust_settlements["Loan_Amount"].max()

            ratio = (credit_amount / settlement_amount) * 100 if settlement_amount else 0
            if ratio < a or ratio > b:
                continue

            new_loan_window_end = settlement_date + timedelta(days=T + x)
            cust_new_loans = loans[
                (loans["Customer_ID"] == cust_id)
                & (loans["Transaction_Type"] == "NEW LOAN")
                & (loans["Start_Date"].notna())
                & (loans["Start_Date"] >= settlement_date)
                & (loans["Start_Date"] <= new_loan_window_end)
            ]

            if cust_new_loans.empty:
                continue

            new_loan_date = cust_new_loans["Start_Date"].min()

            return_txn = transactions[
                (transactions["Customer_ID"] == cust_id)
                & (transactions["Transaction_Type"].isin(debit_types))
                & (transactions["Derived_Counterparty_ID"] == sender_id)
                & (transactions["Trans_DT"] >= new_loan_date)
            ]

            if return_txn.empty:
                continue

            return_date = return_txn["Trans_DT"].min()

            # ---- Create Alert ----
            alert = {
                "alert_id": f"ALERT_{alert_id_counter:03}",
                "group_id": f"INDIV_{sender_id}",  # Mark as individual sender
                "funded_customer": cust_id,
                "repayment_ratio": ratio,
                "fund_flow": {
                    "initial_credit_date": credit_date.strftime("%d/%m/%Y") if credit_date else None,
                    "settlement_date": settlement_date.strftime("%d/%m/%Y") if settlement_date else None,
                    "new_loan_date": new_loan_date.strftime("%d/%m/%Y") if new_loan_date else None,
                    "return_txn_date": return_date.strftime("%d/%m/%Y") if return_date else None,
                },
                "status": "SUSPECTED_CIRCULAR_FUND_FLOW"
            }
            alerts.append(alert)
            alert_id_counter += 1

    # ---- Save alerts ----
    os.makedirs(output_dir, exist_ok=True)
    alerts_path = os.path.join(output_dir, "alerts.json")
    with open(alerts_path, "w") as f:
        json.dump(alerts, f, indent=2)

    return alerts


# ----------------------------
# CLI Execution
# ----------------------------
if __name__ == "__main__":
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    customers_path = os.path.join(base_dir, "data/customers.csv")
    loans_path = os.path.join(base_dir, "data/loans.csv")
    transactions_path = os.path.join(base_dir, "data/transactions.csv")
    groups_path = os.path.join(base_dir, "output/sender_groups.json")
    params_path = os.path.join(base_dir, "config/params.json")
    output_dir = os.path.join(base_dir, "output")

    detect_fraud(customers_path, loans_path, transactions_path, groups_path, params_path, output_dir)
