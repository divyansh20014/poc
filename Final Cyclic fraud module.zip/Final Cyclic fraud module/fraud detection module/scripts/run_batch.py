import os
from data_ingestion import load_data
from profile_builder import build_profiles
from fraud_detector import detect_fraud
from send_alert import send_alerts  # <-- Import the new alert sender
from update_DB import update_database

def main():
    # -----------------------------
    # Automatically resolve project root
    # -----------------------------
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    data_dir = os.path.join(base_dir, "data")
    output_dir = os.path.join(base_dir, "output")
    config_dir = os.path.join(base_dir, "config")

    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # -----------------------------
    # Step 1: Data Ingestion
    # -----------------------------
    customers_path = os.path.join(data_dir, "customers.csv")
    loans_path = os.path.join(data_dir, "loans.csv")
    transactions_path = os.path.join(data_dir, "transactions.csv")
    params_path = os.path.join(config_dir, "params.json")

    customers, loans, transactions, active_loans = load_data(
        customers_path,
        loans_path,
        transactions_path
    )

    # -----------------------------
    # Step 2: Profile Building
    # -----------------------------
    rel_output, groups_output = build_profiles(
        customers,
        transactions,
        active_loans,
        output_dir
    )
    print(f"Profiles generated: {len(rel_output)} relations and {len(groups_output)} groups.")

    # -----------------------------
    # Step 3: Fraud Detection
    # -----------------------------
    print("Running fraud detection...")
    groups_path = os.path.join(output_dir, "sender_groups.json")

    alerts = detect_fraud(
        customers_path,
        loans_path,
        transactions_path,
        groups_path,
        params_path,
        output_dir
    )

    print(f"Fraud detection complete. {len(alerts)} alerts generated.")
    print(f"Alerts saved at: {os.path.join(output_dir, 'alerts.json')}")

    # -----------------------------
    # Step 4: Send Alerts to API
    # -----------------------------
    if alerts:
        print("Sending alerts to API...")
        send_alerts(os.path.join(output_dir, "alerts.json"))
    else:
        print("No alerts to send.")
        
    # After alerts are sent
    print("Updating DB tables with latest data...")
    update_database()
    print("DB update complete.")

if __name__ == "__main__":
    main()
