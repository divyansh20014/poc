import pandas as pd
import json
import psycopg2
from psycopg2.extras import execute_values
from pathlib import Path
from datetime import datetime

def ensure_tables(cursor, schema):
    """Create required tables if they do not exist"""
    cursor.execute(f"""
    CREATE TABLE IF NOT EXISTS {schema}.Sacom_Loan_testing (
        event_id VARCHAR(50) PRIMARY KEY,
        loan_id VARCHAR(50) NOT NULL,
        transaction_type VARCHAR(50) NOT NULL,
        customer_id VARCHAR(50) NOT NULL,
        loan_type VARCHAR(50),
        loan_amount NUMERIC(18,2),
        start_date DATE,
        settlement_date DATE,
        status VARCHAR(50)
    );
    """)

    cursor.execute(f"""
    CREATE TABLE IF NOT EXISTS {schema}.Sacom_Txn_testing (
        transaction_type VARCHAR(50),
        transaction_id VARCHAR(50) PRIMARY KEY,
        trans_dt DATE,
        counterparty_id VARCHAR(50),
        customer_id VARCHAR(50) NOT NULL,
        amount NUMERIC(18,2),
        customer_account_no VARCHAR(50),
        counterparty_account_no VARCHAR(50),
        counterparty_name TEXT,
        counterparty_bank_name TEXT,
        derived_counterparty_id VARCHAR(50)
    );
    """)

    cursor.execute(f"""
    CREATE TABLE IF NOT EXISTS {schema}.Sacom_Group_testing (
        group_id VARCHAR(50) PRIMARY KEY
    );
    """)

    cursor.execute(f"""
    CREATE TABLE IF NOT EXISTS {schema}.Sacom_GroupXcustomer_testing (
        id SERIAL PRIMARY KEY,
        group_id VARCHAR(50) NOT NULL,
        customer_id VARCHAR(50) NOT NULL
    );
    """)

def safe_date(value):
    """Convert to datetime or return None if NaT/invalid."""
    dt = pd.to_datetime(value, dayfirst=True, errors="coerce")
    return None if pd.isna(dt) else dt

def update_database():
    # -----------------------
    # File Paths
    # -----------------------
    base_path = Path(__file__).resolve().parent.parent
    data_path = base_path / "data"
    output_path = base_path / "output"

    loans_csv = data_path / "loans.csv"
    transactions_csv = data_path / "transactions.csv"
    groups_json_path = output_path / "sender_groups.json"

    # -----------------------
    # Database Config
    # -----------------------
    db_config = {
        "host": "10.0.194.129",
        "port": 5432,
        "dbname": "amldb",
        "user": "postgres",
        "password": "avaAML123"
    }
    schema = "sfd_vi"

    # -----------------------
    # Load Data
    # -----------------------
    loans_df = pd.read_csv(loans_csv)
    txns_df = pd.read_csv(transactions_csv)
    groups_data = json.load(open(groups_json_path))

    # -----------------------
    # Connect to DB
    # -----------------------
    conn = psycopg2.connect(**db_config)
    cursor = conn.cursor()

    ensure_tables(cursor, schema)

    # -----------------------
    # Insert Loans
    # -----------------------
    loan_rows = [
        (
            row.Event_ID,
            row.Loan_ID,
            row.Transaction_Type,
            row.Customer_ID,
            row.Loan_Type,
            float(row.Loan_Amount),
            safe_date(row.Start_Date),
            safe_date(row.Settlement_Date),
            row.Status
        )
        for _, row in loans_df.iterrows()
    ]

    execute_values(cursor, f"""
        INSERT INTO {schema}.Sacom_Loan_testing
        (event_id, loan_id, transaction_type, customer_id, loan_type, loan_amount, start_date, settlement_date, status)
        VALUES %s
        ON CONFLICT (event_id) DO NOTHING
    """, loan_rows)

    # -----------------------
    # Insert Transactions
    # -----------------------
    txn_rows = [
        (
            row.Transaction_Type,
            row.Transaction_ID,
            safe_date(row.Trans_DT),
            row.CounterParty_ID if pd.notnull(row.CounterParty_ID) else None,
            row.Customer_ID,
            float(row.Amount),
            row.Customer_Account_No if pd.notnull(row.Customer_Account_No) else None,
            row.Counterparty_Account_No if pd.notnull(row.Counterparty_Account_No) else None,
            row.Counterparty_Name if pd.notnull(row.Counterparty_Name) else None,
            row.Counterparty_Bank_Name if pd.notnull(row.Counterparty_Bank_Name) else None,
            row.Derived_Counterparty_ID if pd.notnull(row.Derived_Counterparty_ID) else None
        )
        for _, row in txns_df.iterrows()
    ]

    execute_values(cursor, f"""
        INSERT INTO {schema}.Sacom_Txn_testing
        (transaction_type, transaction_id, trans_dt, counterparty_id, customer_id, amount,
         customer_account_no, counterparty_account_no, counterparty_name,
         counterparty_bank_name, derived_counterparty_id)
        VALUES %s
        ON CONFLICT (transaction_id) DO NOTHING
    """, txn_rows)

    # -----------------------
    # Assign unique Group IDs
    # -----------------------
    timestamp_suffix = datetime.now().strftime("%Y%m%d%H%M%S")
    unique_groups = []
    counter = 1
    for group in groups_data:
        new_group_id = f"GRP_{timestamp_suffix}_{counter:03}"
        unique_groups.append({"group_id": new_group_id, "group_members": group["group_members"]})
        counter += 1

    # -----------------------
    # Insert Groups
    # -----------------------
    group_rows = [(g["group_id"],) for g in unique_groups]

    execute_values(cursor, f"""
        INSERT INTO {schema}.Sacom_Group_testing
        (group_id)
        VALUES %s
    """, group_rows)

    # -----------------------
    # Insert GroupXCustomer
    # -----------------------
    group_x_customer_rows = []
    for g in unique_groups:
        gid = g["group_id"]
        for cust in g["group_members"]:
            group_x_customer_rows.append((gid, cust))

    execute_values(cursor, f"""
        INSERT INTO {schema}.Sacom_GroupXcustomer_testing
        (group_id, customer_id)
        VALUES %s
    """, group_x_customer_rows)

    # Commit and close
    conn.commit()
    cursor.close()
    conn.close()

    print("? Data successfully inserted into Sacom_*_testing tables with unique group IDs.")

if __name__ == "__main__":
    update_database()
