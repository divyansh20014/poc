import json
from pathlib import Path

def generate_alerts(alerts, output_dir):
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    with open(f"{output_dir}/alerts.json", "w") as f:
        json.dump(alerts, f, indent=2)
