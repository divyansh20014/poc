import json
import os
from collections import defaultdict, deque

def build_profiles(customers, transactions, active_loans, output_dir):
    """
    Build customer-counterparty relationship profiles and sender groups
    """

    # -------------------------------
    # Step 1: Build Customer-Counterparty Relationships
    # -------------------------------
    relation_data = defaultdict(lambda: {'total_amount': 0, 'txn_count': 0, 'active_loan_flag': False})

    # Transaction types considered for relationships
    qualifying_types = {'CREDIT_INT_TRANSFER', 'CREDIT_EXT_TRANSFER', 'CASH_CREDIT', 'DEBIT_EXT_TRANSFER'}

    for _, row in transactions.iterrows():
        txn_type = str(row['Transaction_Type']).strip()
        if txn_type not in qualifying_types:
            continue

        cust_id = str(row['Customer_ID']).strip()
        counterparty_id = str(row['Derived_Counterparty_ID']).strip()

        # Skip invalid rows
        if not cust_id or not counterparty_id or counterparty_id.lower() in ('nan', ''):
            continue

        # Create unordered pair for consistency
        pair = tuple(sorted([cust_id, counterparty_id]))

        # Update amounts and counts
        relation_data[pair]['total_amount'] += float(row['Amount'])
        relation_data[pair]['txn_count'] += 1

        # Active loan flag if either has active loan
        if cust_id in active_loans or counterparty_id in active_loans:
            relation_data[pair]['active_loan_flag'] = True

    # Apply thresholds and form relationship list
    relations_output = []
    for (cust1, cust2), data in relation_data.items():
        threshold = 800_000_000 if data['active_loan_flag'] else 200_000_000
        if data['txn_count'] >= 3 and data['total_amount'] >= threshold:
            relations_output.append({
                "customer_id_1": cust1,
                "customer_id_2": cust2,
                "total_amount": data['total_amount'],
                "txn_count": data['txn_count'],
                "active_loan_flag": data['active_loan_flag']
            })

    # Save relationships
    rel_path = os.path.join(output_dir, 'customer_counterparty_rel.json')
    with open(rel_path, 'w') as f:
        json.dump(relations_output, f, indent=2)

    # -------------------------------
    # Step 2: Build Groups (Declared + Transactional)
    # -------------------------------
    graph = defaultdict(set)

    # Add edges from declared relationships
    for _, row in customers.iterrows():
        cust_id = str(row['Customer_ID']).strip()
        declared_str = str(row['Declared_Related_Customer']).strip()

        if declared_str and declared_str.lower() not in ('nan', '', '[]'):
            # Normalize: remove extra brackets or quotes accidentally stored
            clean_str = declared_str.replace('[', '').replace(']', '').replace("'", "")
            related_ids = [
                r.strip() for r in clean_str.replace(',', ';').split(';') if r.strip()
            ]
            for related in related_ids:
                graph[cust_id].add(related)
                graph[related].add(cust_id)

    # Add edges from transactional relationships (meeting thresholds)
    for rel in relations_output:
        c1, c2 = rel['customer_id_1'], rel['customer_id_2']
        graph[c1].add(c2)
        graph[c2].add(c1)

    # BFS to find connected components (groups)
    visited = set()
    groups_output = []
    group_id_counter = 1

    for node in graph:
        if node in visited:
            continue
        queue = deque([node])
        group_members = set()

        while queue:
            current = queue.popleft()
            if current in visited:
                continue
            visited.add(current)
            group_members.add(current)
            for neighbor in graph[current]:
                if neighbor not in visited:
                    queue.append(neighbor)

        if group_members:
            groups_output.append({
                "group_id": f"GRP_{group_id_counter:03}",
                "group_members": sorted(list(group_members)),
                "funded_customers": [],  # To be updated below
                "funded_count": 0
            })
            group_id_counter += 1

    # -------------------------------
    # Step 3: Funded Customers Detection
    # -------------------------------
    funding_tx_types = {"CREDIT_INT_TRANSFER", "CREDIT_EXT_TRANSFER", "CASH_CREDIT"}

    for group in groups_output:
        members = set(group["group_members"])
        funded_customers = set()

        for _, txn in transactions.iterrows():
            txn_type = str(txn["Transaction_Type"]).strip()
            if txn_type not in funding_tx_types:
                continue

            sender = str(txn["Derived_Counterparty_ID"]).strip()
            recipient = str(txn["Customer_ID"]).strip()

            # Sender must be in group; recipient must be outside group
            if sender in members and recipient not in members and recipient and recipient.lower() not in ('nan', ''):
                funded_customers.add(recipient)

        group["funded_customers"] = sorted(funded_customers)
        group["funded_count"] = len(funded_customers)

    # Save groups
    groups_path = os.path.join(output_dir, 'sender_groups.json')
    with open(groups_path, 'w') as f:
        json.dump(groups_output, f, indent=2)

    return relations_output, groups_output
