import requests
import json
import uuid
import os
import urllib3

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def get_access_token():
    """
    Fetch OAuth access token from SASLogon
    """
    auth_url = "https://bare2.metal.com:443/SASLogon/oauth/token"
    auth_headers = {
        "Accept": "application/json",
        "Content-type": "application/x-www-form-urlencoded",
        "Authorization": "Basic c2FzLmVjOg=="
    }
    auth_data = {
        "grant_type": "password",
        "username": "dip",
        "password": "Admin1234567"
    }

    resp = requests.post(auth_url, headers=auth_headers, data=auth_data, verify=False)
    if resp.status_code != 200:
        print(f"? Token fetch failed: {resp.status_code} {resp.text}")
        return None

    token = resp.json().get("access_token")
    if not token:
        print("? No access token received.")
    return token

def send_alerts(alerts_path):
    """
    Send alerts from alerts.json to SVI Alert API
    """
    token = get_access_token()
    if not token:
        return

    # Load alerts
    if not os.path.exists(alerts_path):
        print(f"? Alerts file not found: {alerts_path}")
        return

    with open(alerts_path, "r") as f:
        alerts = json.load(f)

    endpoint_url = "https://bare2.metal.com/svi-alert/alertingEvents"
    headers = {
        "Accept": "application/vnd.sas.collection+json",
        "Content-Type": "application/vnd.sas.investigation.triage.alerting.data.nested+json",
        "Authorization": f"Bearer {token}"
    }

    for alert in alerts:
        # Use funded_customer as actionable entity
        customer_id = alert.get("funded_customer")
        if not customer_id:
            print("? Skipping alert without funded_customer.")
            continue

        alert_id = str(uuid.uuid4())
        scenario_id = str(uuid.uuid4())

        payload = {
            "jsonLayout": "nested",
            "alertingEvents": [
                {
                    "alertingEventId": alert_id,
                    "actionableEntityType": "scom_customer",
                    "actionableEntityId": customer_id,
                    "alertOriginCode": "Loan_00123",
                    "alertTypeCode": "Loan Fraud",
                    "domain_id": "sfd_domain",
                    "recommendedQueueId": "sfd_low_risk",
                    "alert_trigger_txt": "Customer repay loan illegally",
                    "scenarioFiredEvents": [
                        {
                            "scenarioFiredEventId": scenario_id,
                            "scenarioFiredEntityType": "sacom_customer",
                            "scenarioFiredEntityId": customer_id,
                            "scenarioOriginCode": "SCEN_001",
                            "scenarioId": "S1",
                            "score_val": alert.get("risk_score", 100),
                            "scenarioDescription": (
                                "Loan recycling involving rapid settlement and re-disbursal of funds "
                                "within a group of related customers"
                            ),
                            "replicateFlag": "false",
                            "replicationPolicy": "INTERNAL",
                            "contextRelationshipName": "",
                            "displayFlag": "true",
                            "displayTypeCode": "text",
                            "displayOrder": 1,
                            "rule_id": "SCOM001",
                            "contributingObjects": [
                                {
                                    "contributingObjectType": "sacom loan",
                                    "contributingObjectId": alert.get("loan_new_id", "sacom_loan"),
                                    "triggeringFlag": "true",
                                    "workspaceFlag": "false",
                                    "replicateFlag": "false"
                                }
                            ]
                        }
                    ]
                }
            ]
        }

        # Send POST request
        resp = requests.post(endpoint_url, headers=headers, json=payload, verify=False)

        if resp.status_code == 201:
            print(f"? Alert sent for customer {customer_id}")
        else:
            print(f"? Failed for {customer_id}: {resp.status_code} - {resp.text}")

if __name__ == "__main__":
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    alerts_path = os.path.join(base_dir, "output", "alerts.json")
    send_alerts(alerts_path)
