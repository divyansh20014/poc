import pandas as pd
import os

def load_data(customers_path, loans_path, transactions_path):
    """
    Load and preprocess customers, loans, and transactions data
    """
    # Load CSVs
    customers = pd.read_csv(customers_path)
    loans = pd.read_csv(loans_path)
    transactions = pd.read_csv(transactions_path)

    # Convert date fields to datetime
    date_fields_loans = ['Start_Date', 'Settlement_Date']
    for col in date_fields_loans:
        if col in loans.columns:
            loans[col] = pd.to_datetime(loans[col], errors='coerce', dayfirst=True)

    if 'Trans_DT' in transactions.columns:
        transactions['Trans_DT'] = pd.to_datetime(transactions['Trans_DT'], errors='coerce', dayfirst=True)

    # Clean Declared_Related_Customer (split into list)
    if 'Declared_Related_Customer' in customers.columns:
        customers['Declared_Related_Customer'] = customers['Declared_Related_Customer'].fillna('')
        customers['Declared_Related_Customer'] = customers['Declared_Related_Customer'].apply(
            lambda x: [i.strip() for i in x.split(';') if i.strip()]
        )

    # Mark active loans
    active_loans = loans[loans['Status'].str.lower() == 'active']['Customer_ID'].unique().tolist()

    return customers, loans, transactions, active_loans
